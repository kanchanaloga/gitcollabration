package com.niit.ba.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Person 
{

	@Id
	private int personname;
	@Column(name="persondob")
	private String persondob;
	public int getPersonname() {
		return personname;
	}
	public void setPersonname(int personname) {
		this.personname = personname;
	}
	public String getPersondob() {
		return persondob;
	}
	public void setPersondob(String persondob) {
		this.persondob = persondob;
	}
	
	
	
}
